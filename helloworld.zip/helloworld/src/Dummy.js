import React from 'react';

class Dummy extends React.Component {
    render() {
        return (
            <h1>I am a dummy Component</h1>
        )
    }
}

export default Dummy;