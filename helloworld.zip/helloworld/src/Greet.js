import React from 'react';

class Greet extends React.Component {
    render() {
        this.props.name = 'ajhveudvdb';
        return (
        <h1>{this.props.name}</h1>
        )
    }
}

export default Greet;